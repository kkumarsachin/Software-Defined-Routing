#ifndef INIT_H_
#define INIT_H_

void init_response(int sock_index);

#endif
