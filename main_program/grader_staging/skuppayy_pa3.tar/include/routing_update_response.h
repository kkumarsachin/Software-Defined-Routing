#ifndef ROUTING_UPDATE_RESPONSE_H_
#define ROUTING_UPDATE_RESPONSE_H_

void routing_update_response(int sock_index);

#endif
