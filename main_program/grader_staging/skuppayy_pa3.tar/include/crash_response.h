#ifndef CRASH_RESPONSE_H_
#define CRASH_RESPONSE_H_

void crash_response(int sock_index);

#endif
