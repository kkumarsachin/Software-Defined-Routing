#ifndef UPDATE_RESPONSE_H_
#define UPDATE_RESPONSE_H_

void update_response(int sock_index);

#endif
